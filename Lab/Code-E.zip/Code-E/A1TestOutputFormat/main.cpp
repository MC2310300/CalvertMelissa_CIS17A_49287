/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Melissa
 *
 * Created on September 5, 2020, 2:46 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int num1;
    double num2;
    
    cin >> num1;
    cin >> num2;
    
    cout << num1 << endl;
    cout << num2 << endl;
    cout << "Hello World     " << endl;
    cout << "\tTab it!"<<endl;
    cout << "Compare . . . to space   ";
    
    return 0;
}

