/* 
 * File:   main.cpp
 * Author: Melissa
 *
 * Created on September 1, 2020, 9:26 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << "Hello World";
    return 0;
}

